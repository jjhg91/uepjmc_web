<?php 
require('menu.php');
inicio();
head();  
?>
    <!--Base typography -->
    <section class="section section-lg bg-default">
        <div class="container">
          <div class="row ">
            <div class="col-xl-12">
                <div>
                    <img src="images/reglamento.PNG" alt="" width="1200" height="1200"/>
                </div>
            </div>
          </div>
        </div>
      </section>         
      <?php 
        footer();
      ?>
